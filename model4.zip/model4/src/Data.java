public class Data {
    private Integer id;

    private Double ckOoNumberofprivatemethods;

    private Double ldhhLcom;

    private Double ldhhFanin;

    private Double numberofnontrivialbugsfounduntil;

    private Double wchuNumberofpublicattributes;

    private Double wchuNumberofattributes;

    private Double cvswentropy;

    private Double ldhhNumberofpublicmethods;

    private Double wchuFanin;

    private Double ldhhNumberofprivateattributes;

    private Double cvsentropy;

    private Double ldhhNumberofpublicattributes;

    private Double wchuNumberofprivatemethods;

    private Double wchuNumberofmethods;

    private Double ckOoNumberofpublicattributes;

    private Double ckOoNoc;

    private Double numberofcriticalbugsfounduntil;

    private Double ckOoWmc;

    private Double ldhhNumberofprivatemethods;

    private Double wchuNumberofprivateattributes;

    private Double wchuNoc;

    private Double ckOoFanout;

    private Double cvslogentropy;

    private Double ldhhNumberofattributesinherited;

    private Double ckOoNumberoflinesofcode;

    private Double ckOoDit;

    private Double wchuWmc;

    private Double ldhhNoc;

    private Double ckOoNumberofmethods;

    private Double ckOoNumberofattributesinherited;

    private Double wchuDit;

    private Double ckOoLcom;

    private Double ckOoFanin;

    private Double wchuNumberofattributesinherited;

    private Double ckOoRfc;

    private Double ldhhWmc;

    private Double ldhhNumberofattributes;

    private Double ldhhNumberoflinesofcode;

    private Double wchuFanout;

    private Double wchuLcom;

    private Double ckOoCbo;

    private Double wchuRfc;

    private Double ckOoNumberofattributes;

    private Double numberofhighprioritybugsfounduntil;

    private Double ckOoNumberofprivateattributes;

    private Double numberofmajorbugsfounduntil;

    private Double wchuNumberofpublicmethods;

    private Double ldhhDit;

    private Double wchuCbo;

    private Double cvslinentropy;

    private Double wchuNumberofmethodsinherited;

    private Double numberofbugsfounduntil;

    private Double ldhhFanout;

    private Double ldhhNumberofmethodsinherited;

    private Double ldhhRfc;

    private Double ckOoNumberofmethodsinherited;

    private Double ckOoNumberofpublicmethods;

    private Double ldhhCbo;

    private Double wchuNumberoflinesofcode;

    private Double cvsexpentropy;

    private Double ldhhNumberofmethods;

    private Double classes;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getCkOoNumberofprivatemethods() {
        return ckOoNumberofprivatemethods;
    }

    public void setCkOoNumberofprivatemethods(Double ckOoNumberofprivatemethods) {
        this.ckOoNumberofprivatemethods = ckOoNumberofprivatemethods;
    }

    public Double getLdhhLcom() {
        return ldhhLcom;
    }

    public void setLdhhLcom(Double ldhhLcom) {
        this.ldhhLcom = ldhhLcom;
    }

    public Double getLdhhFanin() {
        return ldhhFanin;
    }

    public void setLdhhFanin(Double ldhhFanin) {
        this.ldhhFanin = ldhhFanin;
    }

    public Double getNumberofnontrivialbugsfounduntil() {
        return numberofnontrivialbugsfounduntil;
    }

    public void setNumberofnontrivialbugsfounduntil(Double numberofnontrivialbugsfounduntil) {
        this.numberofnontrivialbugsfounduntil = numberofnontrivialbugsfounduntil;
    }

    public Double getWchuNumberofpublicattributes() {
        return wchuNumberofpublicattributes;
    }

    public void setWchuNumberofpublicattributes(Double wchuNumberofpublicattributes) {
        this.wchuNumberofpublicattributes = wchuNumberofpublicattributes;
    }

    public Double getWchuNumberofattributes() {
        return wchuNumberofattributes;
    }

    public void setWchuNumberofattributes(Double wchuNumberofattributes) {
        this.wchuNumberofattributes = wchuNumberofattributes;
    }

    public Double getCvswentropy() {
        return cvswentropy;
    }

    public void setCvswentropy(Double cvswentropy) {
        this.cvswentropy = cvswentropy;
    }

    public Double getLdhhNumberofpublicmethods() {
        return ldhhNumberofpublicmethods;
    }

    public void setLdhhNumberofpublicmethods(Double ldhhNumberofpublicmethods) {
        this.ldhhNumberofpublicmethods = ldhhNumberofpublicmethods;
    }

    public Double getWchuFanin() {
        return wchuFanin;
    }

    public void setWchuFanin(Double wchuFanin) {
        this.wchuFanin = wchuFanin;
    }

    public Double getLdhhNumberofprivateattributes() {
        return ldhhNumberofprivateattributes;
    }

    public void setLdhhNumberofprivateattributes(Double ldhhNumberofprivateattributes) {
        this.ldhhNumberofprivateattributes = ldhhNumberofprivateattributes;
    }

    public Double getCvsentropy() {
        return cvsentropy;
    }

    public void setCvsentropy(Double cvsentropy) {
        this.cvsentropy = cvsentropy;
    }

    public Double getLdhhNumberofpublicattributes() {
        return ldhhNumberofpublicattributes;
    }

    public void setLdhhNumberofpublicattributes(Double ldhhNumberofpublicattributes) {
        this.ldhhNumberofpublicattributes = ldhhNumberofpublicattributes;
    }

    public Double getWchuNumberofprivatemethods() {
        return wchuNumberofprivatemethods;
    }

    public void setWchuNumberofprivatemethods(Double wchuNumberofprivatemethods) {
        this.wchuNumberofprivatemethods = wchuNumberofprivatemethods;
    }

    public Double getWchuNumberofmethods() {
        return wchuNumberofmethods;
    }

    public void setWchuNumberofmethods(Double wchuNumberofmethods) {
        this.wchuNumberofmethods = wchuNumberofmethods;
    }

    public Double getCkOoNumberofpublicattributes() {
        return ckOoNumberofpublicattributes;
    }

    public void setCkOoNumberofpublicattributes(Double ckOoNumberofpublicattributes) {
        this.ckOoNumberofpublicattributes = ckOoNumberofpublicattributes;
    }

    public Double getCkOoNoc() {
        return ckOoNoc;
    }

    public void setCkOoNoc(Double ckOoNoc) {
        this.ckOoNoc = ckOoNoc;
    }

    public Double getNumberofcriticalbugsfounduntil() {
        return numberofcriticalbugsfounduntil;
    }

    public void setNumberofcriticalbugsfounduntil(Double numberofcriticalbugsfounduntil) {
        this.numberofcriticalbugsfounduntil = numberofcriticalbugsfounduntil;
    }

    public Double getCkOoWmc() {
        return ckOoWmc;
    }

    public void setCkOoWmc(Double ckOoWmc) {
        this.ckOoWmc = ckOoWmc;
    }

    public Double getLdhhNumberofprivatemethods() {
        return ldhhNumberofprivatemethods;
    }

    public void setLdhhNumberofprivatemethods(Double ldhhNumberofprivatemethods) {
        this.ldhhNumberofprivatemethods = ldhhNumberofprivatemethods;
    }

    public Double getWchuNumberofprivateattributes() {
        return wchuNumberofprivateattributes;
    }

    public void setWchuNumberofprivateattributes(Double wchuNumberofprivateattributes) {
        this.wchuNumberofprivateattributes = wchuNumberofprivateattributes;
    }

    public Double getWchuNoc() {
        return wchuNoc;
    }

    public void setWchuNoc(Double wchuNoc) {
        this.wchuNoc = wchuNoc;
    }

    public Double getCkOoFanout() {
        return ckOoFanout;
    }

    public void setCkOoFanout(Double ckOoFanout) {
        this.ckOoFanout = ckOoFanout;
    }

    public Double getCvslogentropy() {
        return cvslogentropy;
    }

    public void setCvslogentropy(Double cvslogentropy) {
        this.cvslogentropy = cvslogentropy;
    }

    public Double getLdhhNumberofattributesinherited() {
        return ldhhNumberofattributesinherited;
    }

    public void setLdhhNumberofattributesinherited(Double ldhhNumberofattributesinherited) {
        this.ldhhNumberofattributesinherited = ldhhNumberofattributesinherited;
    }

    public Double getCkOoNumberoflinesofcode() {
        return ckOoNumberoflinesofcode;
    }

    public void setCkOoNumberoflinesofcode(Double ckOoNumberoflinesofcode) {
        this.ckOoNumberoflinesofcode = ckOoNumberoflinesofcode;
    }

    public Double getCkOoDit() {
        return ckOoDit;
    }

    public void setCkOoDit(Double ckOoDit) {
        this.ckOoDit = ckOoDit;
    }

    public Double getWchuWmc() {
        return wchuWmc;
    }

    public void setWchuWmc(Double wchuWmc) {
        this.wchuWmc = wchuWmc;
    }

    public Double getLdhhNoc() {
        return ldhhNoc;
    }

    public void setLdhhNoc(Double ldhhNoc) {
        this.ldhhNoc = ldhhNoc;
    }

    public Double getCkOoNumberofmethods() {
        return ckOoNumberofmethods;
    }

    public void setCkOoNumberofmethods(Double ckOoNumberofmethods) {
        this.ckOoNumberofmethods = ckOoNumberofmethods;
    }

    public Double getCkOoNumberofattributesinherited() {
        return ckOoNumberofattributesinherited;
    }

    public void setCkOoNumberofattributesinherited(Double ckOoNumberofattributesinherited) {
        this.ckOoNumberofattributesinherited = ckOoNumberofattributesinherited;
    }

    public Double getWchuDit() {
        return wchuDit;
    }

    public void setWchuDit(Double wchuDit) {
        this.wchuDit = wchuDit;
    }

    public Double getCkOoLcom() {
        return ckOoLcom;
    }

    public void setCkOoLcom(Double ckOoLcom) {
        this.ckOoLcom = ckOoLcom;
    }

    public Double getCkOoFanin() {
        return ckOoFanin;
    }

    public void setCkOoFanin(Double ckOoFanin) {
        this.ckOoFanin = ckOoFanin;
    }

    public Double getWchuNumberofattributesinherited() {
        return wchuNumberofattributesinherited;
    }

    public void setWchuNumberofattributesinherited(Double wchuNumberofattributesinherited) {
        this.wchuNumberofattributesinherited = wchuNumberofattributesinherited;
    }

    public Double getCkOoRfc() {
        return ckOoRfc;
    }

    public void setCkOoRfc(Double ckOoRfc) {
        this.ckOoRfc = ckOoRfc;
    }

    public Double getLdhhWmc() {
        return ldhhWmc;
    }

    public void setLdhhWmc(Double ldhhWmc) {
        this.ldhhWmc = ldhhWmc;
    }

    public Double getLdhhNumberofattributes() {
        return ldhhNumberofattributes;
    }

    public void setLdhhNumberofattributes(Double ldhhNumberofattributes) {
        this.ldhhNumberofattributes = ldhhNumberofattributes;
    }

    public Double getLdhhNumberoflinesofcode() {
        return ldhhNumberoflinesofcode;
    }

    public void setLdhhNumberoflinesofcode(Double ldhhNumberoflinesofcode) {
        this.ldhhNumberoflinesofcode = ldhhNumberoflinesofcode;
    }

    public Double getWchuFanout() {
        return wchuFanout;
    }

    public void setWchuFanout(Double wchuFanout) {
        this.wchuFanout = wchuFanout;
    }

    public Double getWchuLcom() {
        return wchuLcom;
    }

    public void setWchuLcom(Double wchuLcom) {
        this.wchuLcom = wchuLcom;
    }

    public Double getCkOoCbo() {
        return ckOoCbo;
    }

    public void setCkOoCbo(Double ckOoCbo) {
        this.ckOoCbo = ckOoCbo;
    }

    public Double getWchuRfc() {
        return wchuRfc;
    }

    public void setWchuRfc(Double wchuRfc) {
        this.wchuRfc = wchuRfc;
    }

    public Double getCkOoNumberofattributes() {
        return ckOoNumberofattributes;
    }

    public void setCkOoNumberofattributes(Double ckOoNumberofattributes) {
        this.ckOoNumberofattributes = ckOoNumberofattributes;
    }

    public Double getNumberofhighprioritybugsfounduntil() {
        return numberofhighprioritybugsfounduntil;
    }

    public void setNumberofhighprioritybugsfounduntil(Double numberofhighprioritybugsfounduntil) {
        this.numberofhighprioritybugsfounduntil = numberofhighprioritybugsfounduntil;
    }

    public Double getCkOoNumberofprivateattributes() {
        return ckOoNumberofprivateattributes;
    }

    public void setCkOoNumberofprivateattributes(Double ckOoNumberofprivateattributes) {
        this.ckOoNumberofprivateattributes = ckOoNumberofprivateattributes;
    }

    public Double getNumberofmajorbugsfounduntil() {
        return numberofmajorbugsfounduntil;
    }

    public void setNumberofmajorbugsfounduntil(Double numberofmajorbugsfounduntil) {
        this.numberofmajorbugsfounduntil = numberofmajorbugsfounduntil;
    }

    public Double getWchuNumberofpublicmethods() {
        return wchuNumberofpublicmethods;
    }

    public void setWchuNumberofpublicmethods(Double wchuNumberofpublicmethods) {
        this.wchuNumberofpublicmethods = wchuNumberofpublicmethods;
    }

    public Double getLdhhDit() {
        return ldhhDit;
    }

    public void setLdhhDit(Double ldhhDit) {
        this.ldhhDit = ldhhDit;
    }

    public Double getWchuCbo() {
        return wchuCbo;
    }

    public void setWchuCbo(Double wchuCbo) {
        this.wchuCbo = wchuCbo;
    }

    public Double getCvslinentropy() {
        return cvslinentropy;
    }

    public void setCvslinentropy(Double cvslinentropy) {
        this.cvslinentropy = cvslinentropy;
    }

    public Double getWchuNumberofmethodsinherited() {
        return wchuNumberofmethodsinherited;
    }

    public void setWchuNumberofmethodsinherited(Double wchuNumberofmethodsinherited) {
        this.wchuNumberofmethodsinherited = wchuNumberofmethodsinherited;
    }

    public Double getNumberofbugsfounduntil() {
        return numberofbugsfounduntil;
    }

    public void setNumberofbugsfounduntil(Double numberofbugsfounduntil) {
        this.numberofbugsfounduntil = numberofbugsfounduntil;
    }

    public Double getLdhhFanout() {
        return ldhhFanout;
    }

    public void setLdhhFanout(Double ldhhFanout) {
        this.ldhhFanout = ldhhFanout;
    }

    public Double getLdhhNumberofmethodsinherited() {
        return ldhhNumberofmethodsinherited;
    }

    public void setLdhhNumberofmethodsinherited(Double ldhhNumberofmethodsinherited) {
        this.ldhhNumberofmethodsinherited = ldhhNumberofmethodsinherited;
    }

    public Double getLdhhRfc() {
        return ldhhRfc;
    }

    public void setLdhhRfc(Double ldhhRfc) {
        this.ldhhRfc = ldhhRfc;
    }

    public Double getCkOoNumberofmethodsinherited() {
        return ckOoNumberofmethodsinherited;
    }

    public void setCkOoNumberofmethodsinherited(Double ckOoNumberofmethodsinherited) {
        this.ckOoNumberofmethodsinherited = ckOoNumberofmethodsinherited;
    }

    public Double getCkOoNumberofpublicmethods() {
        return ckOoNumberofpublicmethods;
    }

    public void setCkOoNumberofpublicmethods(Double ckOoNumberofpublicmethods) {
        this.ckOoNumberofpublicmethods = ckOoNumberofpublicmethods;
    }

    public Double getLdhhCbo() {
        return ldhhCbo;
    }

    public void setLdhhCbo(Double ldhhCbo) {
        this.ldhhCbo = ldhhCbo;
    }

    public Double getWchuNumberoflinesofcode() {
        return wchuNumberoflinesofcode;
    }

    public void setWchuNumberoflinesofcode(Double wchuNumberoflinesofcode) {
        this.wchuNumberoflinesofcode = wchuNumberoflinesofcode;
    }

    public Double getCvsexpentropy() {
        return cvsexpentropy;
    }

    public void setCvsexpentropy(Double cvsexpentropy) {
        this.cvsexpentropy = cvsexpentropy;
    }

    public Double getLdhhNumberofmethods() {
        return ldhhNumberofmethods;
    }

    public void setLdhhNumberofmethods(Double ldhhNumberofmethods) {
        this.ldhhNumberofmethods = ldhhNumberofmethods;
    }

    public Double getClasses() {
        return classes;
    }

    public void setClasses(Double classes) {
        this.classes = classes;
    }
}