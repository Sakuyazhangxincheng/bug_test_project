import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static java.lang.Math.random;

public class Main {

    public static double eta = 0.1;//步长，默认为1
    public static double[] w = new double[61];
    public static int b = 7;

    public static List<Point> arrayList;
    public static void main(String[] args) {
        for(int i=0; i<w.length; i++)
            w[i] = random()*10;

        ArrayList<String> records = new ArrayList<>();
        arrayList = new ArrayList<>();

        records = readCsvByBufferedReader("JDT.csv");
        System.out.println();
        for(int x=1; x<records.size(); x++) {
            String[] lineRecords = records.get(x).split(",");
            double[] drecord = new double[lineRecords.length];
            double[] tdrecord = new double[drecord.length-1];

            for(int i=0; i<lineRecords.length; i++) {
                if(lineRecords[i].equals("clean"))
                    drecord[i] = 1.0;
                else if (lineRecords[i].equals("buggy"))
                    drecord[i] = -1.0;
                else drecord[i] = Double.valueOf(lineRecords[i]);
                if(i != (lineRecords.length-1))
                    tdrecord[i] = drecord[i];
            }

            Point P = new Point(tdrecord, drecord[drecord.length-1]);
            arrayList.add(P);
        }

//        Point p1 = new Point(new double[]{0, 0, 0, 1}, -1);
//        Point p2 = new Point(new double[]{1, 0, 0, 0}, 1);
//        Point p3 = new Point(new double[]{2, 1, 0, 0}, 1);
//        Point p4 = new Point(new double[]{2, 1, 0, 1}, -1);
//
//        arrayList.add(p1);
//        arrayList.add(p2);
//        arrayList.add(p3);
//        arrayList.add(p4);

        boolean classify = classify();

        double accn = 0;
        for(int x=500; x<700; x++) {
            String[] lineRecords = records.get(x).split(",");
            double[] drecord = new double[lineRecords.length];
            double[] tdrecord = new double[drecord.length - 1];

            for(int i=0; i<lineRecords.length; i++) {
                if(lineRecords[i].equals("clean"))
                    drecord[i] = 1.0;
                else if (lineRecords[i].equals("buggy"))
                    drecord[i] = -1.0;
                else drecord[i] = Double.valueOf(lineRecords[i]);
                if(i != (lineRecords.length-1))
                    tdrecord[i] = drecord[i];
            }

            double answer = 0;
            for(int y=0; y<tdrecord.length; y++){
                answer += tdrecord[y] * w[y];
            }

            if((answer * drecord[lineRecords.length-1]) > 0)
                accn++;
            //System.out.println(drecord[lineRecords.length-1] + "|" + answer);
        }
        System.out.println("准确率：" + accn/200);
    }

    /*
     * 判断所有点的位置关系,进行分类
     */
    public static boolean classify() {
        int r = 0;
        boolean flag = false;
        while (!flag) {
            for (int i = 0; i < arrayList.size(); i++) {
                if (Anwser(arrayList.get(i)) <= 0) {
                    Update(arrayList.get(i));
                    r++;
                    break;
                }
                if (i + 1 == arrayList.size()) {
                    flag = true;
                }
            }
            if(r >5000) break;
        }
        return true;
    }

    /*
     * 点乘返回sum
     */
    private static double Dot(double[] w, double[] x) {
        double sum = 0;
        for (int i = 0; i < x.length; i++) {
            sum += w[i] * x[i];
        }
        return sum;
    }

    /*
     * 返回函数计算的值
     */
    private static double Anwser(Point point) {
        System.out.println("w:"+Arrays.toString(w));
        System.out.println("b:"+b);
        return point.y * (Dot(w, point.x) + b);
    }

    public static void Update(Point point) {
        for (int i = 0; i < w.length; i++) {
            w[i] += eta * point.y * point.x[i];
        }
        b += eta * point.y;
        return;
    }

    public static ArrayList<String> readCsvByBufferedReader(String filePath) {
        File csv = new File(filePath);
        csv.setReadable(true);
        csv.setWritable(true);
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
            isr = new InputStreamReader(new FileInputStream(csv), "UTF-8");
            br = new BufferedReader(isr);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String line = "";
        ArrayList<String> records = new ArrayList<>();
        try {
            while ((line = br.readLine()) != null) {
                //System.out.println(line);
                records.add(line);
            }
            System.out.println("csv表格读取行数：" + records.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }
}
class Point{
    double x[];
    double y;

    public Point(double[] x, double y) {
        this.x = x;
        this.y = y;
    }
}

